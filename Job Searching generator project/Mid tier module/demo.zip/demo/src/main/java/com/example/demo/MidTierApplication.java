package com.example.demo;

import com.example.demo.Entity.Job;
import com.example.demo.Service.JobService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SpringBootApplication
@RestController
@RequestMapping("/api")
public class MidTierApplication {

    private final JobService service;

    public MidTierApplication(JobService service) {
        this.service
         = service;
    }

    @PostMapping("/addJob")
    public boolean addJob(@RequestBody Job job) {
        return service.addJob(job);
    }

    @GetMapping("/jobs")
    public List<Job> retrieveValue() {
        return service.retrieveValue();
    }

    @PutMapping("/updateJob/{id}")
    public boolean updateJob(@PathVariable Long id, @RequestBody Job changes) {
        return service.updateJob(id, changes);
    }

    @DeleteMapping("/deleteJob/{id}")
    public boolean deleteJob(@PathVariable Long id) {
        return service.delete(id);
    }

    public static void main(String[] args) {
        SpringApplication.run(MidTierApplication.class, args);
    }
}


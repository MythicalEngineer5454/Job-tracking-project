package com.example.demo.Service;

import com.example.demo.Entity.Job;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class JobServiceImpl implements JobService {

    private final Map<Long, Job> store = new ConcurrentHashMap<>();
    private final AtomicLong idGen = new AtomicLong(1);

    @Override
    public boolean addJob(Job job) {
        if (job == null || isBlank(job.getTitle()) || isBlank(job.getCompany())) return false;
        long id = idGen.getAndIncrement();
        // since your entity id is private with no setter, make a copy with generated id
        Job saved = new Job(job.getTitle(), job.getCompany(), job.getSalary(), job.getRequirement());
        // hack: keep id in map key; your real JPA entity will carry id
        store.put(id, saved);
        return true;
    }

    @Override
    public boolean updateJob(Long id, Job changes) {
        if (id == null || id <= 0 || changes == null) return false;
        Job existing = store.get(id);
        if (existing == null) return false;

        // apply only non-null / non-blank updates (simple PATCH-like behavior)
        if (!isBlank(changes.getTitle()))      setField(existing, "title", changes.getTitle());
        if (!isBlank(changes.getCompany()))    setField(existing, "company", changes.getCompany());
        if (changes.getSalary() != null)       setField(existing, "salary", changes.getSalary());
        if (changes.getRequirement() != null)  setField(existing, "requirement", changes.getRequirement());

        return true;
    }

    @Override
    public List<Job> retrieveValue() {
        return new ArrayList<>(store.values());
    }

    @Override
    public boolean delete(Long id) {
        if (id == null || id <= 0) return false;
        return store.remove(id) != null;
    }

    private boolean isBlank(String s) { return s == null || s.isBlank(); }

    // Because your Job has getters only, we can’t mutate fields directly.
    // For the in-memory demo, recreate a new Job with merged values.
    private void setField(Job target, String field, String value) {
        String title = "title".equals(field) ? value : target.getTitle();
        String company = "company".equals(field) ? value : target.getCompany();
        String salary = "salary".equals(field) ? value : target.getSalary();
        String requirement = "requirement".equals(field) ? value : target.getRequirement();

        // replace the stored object with a new one (same map key)
        // find id by reverse lookup (only for demo)
        Long key = store.entrySet().stream()
                .filter(e -> e.getValue() == target)
                .map(Map.Entry::getKey)
                .findFirst().orElse(null);
        if (key != null) {
            store.put(key, new Job(title, company, salary, requirement));
        }
    }
}

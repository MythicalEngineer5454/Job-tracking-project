package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GenerationType;


@Entity
@Table(name = "saved_jobs")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String title;
    private String company;
    private String salary;

     @Column(columnDefinition = "TEXT")
    private String requirement;

    public Job(){}
    public Job(String t,String c,String s,String r){
        this.title = t;
        this.company = c;
        this.salary = s;
        this.requirement = r;
    }
    public long getId(){
        return id;
    }

    public String getTitle(){
        return title;
    }

    public String getCompany(){
        return company;
    }

    public String getSalary(){
        return salary;
    }

    public String getRequirement(){
        return requirement;
    }





}
